package classes;

import java.util.Set;
import org.jgrapht.graph.DefaultWeightedEdge;

public class Main {

	public static void main(String[] args) {

		GraphI g =  GraphC.getInstance();
		g.addVertices("x1");
		g.addVertices("x2");
		g.addVertices("x3");
		g.addVertices("x4");
		g.addVertices("x5");
		g.addVertices("x6");
		g.addVertices("x7");
		g.addVertices("x8");
		Set<String> sV = g.getVertices();
		g.addEdge("x1", "x2");
		g.setEdgeWeight(g.getGraph().getEdge("x1", "x2"), 5);
		g.addEdge("x2", "x3");
		g.addEdge("x3", "x4");
		g.addEdge("x7", "x8");
		g.addEdge("x4", "x5");
		g.addEdge("x5", "x6");
		g.addEdge("x6", "x7");

		g.setEdgeWeight(g.getGraph().getEdge("x6", "x7"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x2", "x3"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x3","x4"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x4","x5"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x5","x6"), 5);

		g.setEdgeWeight(g.getGraph().getEdge("x7", "x8"), 5);
		g.addEdge("x4", "x7");
		g.addEdge("x6", "x8");
		g.addEdge("x8", "x6");
		g.addEdge("x8", "x2");
		g.addEdge("x7", "x3");
		g.addEdge("x6", "x5");
		g.setEdgeWeight(g.getGraph().getEdge("x4", "x7"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x6", "x8"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x8", "x6"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x8", "x2"), 5);
		g.setEdgeWeight(g.getGraph().getEdge("x7", "x3"), 5);

		g.setEdgeWeight(g.getGraph().getEdge("x6", "x5"), 5);

		Set<DefaultWeightedEdge> sE = g.getEdges();
		for(DefaultWeightedEdge e : sE ){
			System.out.println(g.getGraph().getEdgeWeight(e));
		}

		MasonsF m = new MasonsF();
		double s = m.solveG("x1", "x8");


	}

}
